﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Umove_AS.Type
{
    public enum Season
    {
            Winter,
            Spring,
            Summer,
            Autumn
    }
}
