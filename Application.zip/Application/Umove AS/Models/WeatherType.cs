﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Umove_AS.Models
{
    public enum WeatherType //forhen -> class Weather
    {
        //private double _temperature; //Temperatur i grader Celsius
        //private bool _IsRaining; //True hvis det regner
        WarmDry,
        WarmWet,
        AverageDry,
        AverageWet,
        ColdDry,
        ColdWet,
        FreezeDry,
        FreezeWet,

    }
}
