using System.Windows.Controls;

namespace UMOVEWPF.Views
{
    public partial class BusDetailView : UserControl
    {
        public BusDetailView()
        {
            InitializeComponent();
        }
    }
} 