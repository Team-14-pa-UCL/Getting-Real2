namespace MSTestUmove;

[TestClass]
public class Test2
{
    [TestMethod]
    public void TestMethod1()
    {
    }
}
