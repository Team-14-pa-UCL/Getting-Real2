using System.Windows.Controls;

namespace UMOVEWPF.Views
{
    public partial class BusListView : UserControl
    {
        public BusListView()
        {
            InitializeComponent();
        }
    }
} 